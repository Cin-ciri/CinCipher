/**
 * @(#)PasswordEncrypt.java
 * @author Cin'ciri
 * @version 1.01 2018/12/24 16:35
 * 
 * PROGRAM PURPOSE: TO ENCRYPT THE PASSWORD ENTERED BY THE USER.
 */

package encryption;
import java.util.Arrays;

public class CinCipherEncrypt
{
  private String revPswd;
  private String pswdEn;
  private char en;
  private int shift;
  private String str;
  public char erValEn;
  
  public void Encrypt(int shift)
  {
    if(shift == 0)
    {
      System.out.printf("Shift cannot be 0.%n");
      erValEn = 'N';
    }
    else if(shift < 1 || shift > 94)
    {
      System.out.printf("Shift must be between 1 and 94. You entered %d.%n", shift);
      erValEn = 'N';
    }
    else
    {
      this.shift = shift;
      erValEn = 'Y';
    }
  }
  
  public String Encrypt(String revPswd, String pswdEn, char en, int shift)
  {
   this.revPswd = revPswd;
   this.pswdEn = pswdEn;
   this.en = en;
   String elem = "";
   char[] pswdArray = revPswd.toCharArray();
   char[] pswdEnArray = new char[pswdArray.length];
   char[] baseArray = {'~','!','@','#','$','%','^','&','*','(',')','_','+','`',
      '1','2','3','4','5','6','7','8','9','0','-','=','Q','W','E','R','T','Y','U',
      'I','O','P','{','}','|','q','w','e','r','t','y','u','i','o','p','[',']','\\',
      'A','S','D','F','G','H','J','K','L',':','\"','a','s','d','f','g','h','j','k',
      'l',';','\'','Z','X','C','V','B','N','M','<','>','?','z','x','c','v','b','n',
      'm',',','.','/',' '};

   
   for(int i = 0; i < pswdEnArray.length; i++)
   {
     pswdEn = "";
   for(int j = 0; j < pswdArray.length; j++)
     {
       for(int l = 0; l < baseArray.length; l++)
       {
         if(pswdArray[j] == baseArray[l])
         {
           elem = String.valueOf(baseArray[(l + shift) % baseArray.length]);
           pswdEnArray[i] = elem.charAt(0);
           pswdEn += String.valueOf(pswdEnArray[i]);
           elem = "";
         }
       }
     }  

   } return pswdEn;
  }
  
  }
   


