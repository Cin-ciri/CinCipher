/**
 * @(#)PasswordDecrypt.java
 * @author Cin'ciri
 * @version 1.01 2018/12/24 16:35
 * 
 * PROGRAM PURPOSE: TO DECRYPT THE PASSWORD ENTERED BY THE USER.
 */
package decryption;
import java.util.Arrays;


public class CinCipherDecrypt
{
  private String revPswd;
  private String pswdDe;
  private char de;
  private int shift;
  public char erValDe;
  
  public void Decrypt(int shift)
  {
    if(shift == 0)
    {
      System.out.printf("Shift cannot be 0.%n");
      erValDe = 'N';
    }
    else if(shift < 1 || shift > 94)
    {
      System.out.printf("Shift must be between 1 and 94. You entered %d.%n", shift);
      erValDe = 'N';
    }
    else
    {
      this.shift = shift;
      erValDe = 'Y';
    }
  }//END default
  
  public String Decrypt(String revPswd, String pswdDe, char de, int shift)
  {
   this.revPswd = revPswd;
   this.pswdDe = pswdDe;
   this.de = de;
   this.shift = shift;
   String elem = "";
   char[] pswdArray = revPswd.toCharArray();
   char[] pswdDeArray = new char[pswdArray.length];
   char[] baseArray = {'~','!','@','#','$','%','^','&','*','(',')','_','+','`',
      '1','2','3','4','5','6','7','8','9','0','-','=','Q','W','E','R','T','Y','U',
      'I','O','P','{','}','|','q','w','e','r','t','y','u','i','o','p','[',']','\\',
      'A','S','D','F','G','H','J','K','L',':','\"','a','s','d','f','g','h','j','k',
      'l',';','\'','Z','X','C','V','B','N','M','<','>','?','z','x','c','v','b','n',
      'm',',','.','/',' '};

    for (int i = 0; i < baseArray.length / 2; i++) 
    {
        char temp = baseArray[i];
        baseArray[i] = baseArray[baseArray.length - 1 - i];
        baseArray[baseArray.length - 1 - i] = temp;
    }
    
    for(int i = 0; i < pswdDeArray.length; i++)
   {
     pswdDe = "";
   for(int j = 0; j < pswdArray.length; j++)
     {
       for(int l = 0; l < baseArray.length; l++)
       {
         if(pswdArray[j] == baseArray[l])
         {
           elem = String.valueOf(baseArray[(l + shift) % baseArray.length]);
           pswdDeArray[i] = elem.charAt(0);
           pswdDe += String.valueOf(pswdDeArray[i]);
           elem = "";
         }
       }
     }  

   } 
   
  return pswdDe;
  }
}
