/**
 * @(#)PasswordEncryptDecrypt.java
 * @author Cin'ciri
 * @version 1.01 2018/12/24 16:35
 * 
 * PROGRAM PURPOSE: TO PROVIDE AN ENCRYPTED/DECRYPTED VERSION OF
 * A PASSWORD ENTERED BY THE USER.
 */
import java.util.*;
import encryption.CinCipherEncrypt;
import decryption.CinCipherDecrypt;

public class CinCipher
{
  private static char enDe;
  private static char en;
  private static char de;
  private static char again;
  private static int shift;
  private static CinCipherEncrypt encrypt = new CinCipherEncrypt();
  private static CinCipherDecrypt decrypt = new CinCipherDecrypt();
  private static Scanner input = new Scanner(System.in);
  private static String newPswd;
  private static String pswd;
  private static String pswdEn = "";
  private static String pswdDe = "";
  private static String revPswd;
  private static String revString;
  private static String str;
  private static char erVal;
  private static char enDeVal;
  private static char[] baseArray = {'~','!','@','#','$','%','^','&','*','(',')','_','+','`',
      '1','2','3','4','5','6','7','8','9','0','-','=','Q','W','E','R','T','Y','U',
      'I','O','P','{','}','|','q','w','e','r','t','y','u','i','o','p','[',']','\\',
      'A','S','D','F','G','H','J','K','L',':','\"','a','s','d','f','g','h','j','k',
      'l',';','\'','Z','X','C','V','B','N','M','<','>','?','z','x','c','v','b','n',
      'm',',','.','/',' '};
  
  public static void main(String[] args)
  {   
    do
    {
      pswd = ""; pswdEn = ""; pswdDe = "";
      pswdPrompt(input);
      System.out.printf("Your password is:  %s%n", pswd);
      
      reversePswd(pswd);
      System.out.printf("Your reversed password is:  %s%n", revPswd);
      
         
      enDePrompt(input, revPswd, str);
      shiftPrompt(input);
      enDeSplit(enDe, newPswd);
       
      System.out.printf("Would you like to encrypt/decrypt another password? (Y/N)%n");
      str = input.next();
      input.nextLine();
      again = str.toUpperCase().charAt(0); 
    }while(again == 'Y'); //END do-while
     sysExit();
  } //END main()      
   
  public static String pswdPrompt(Scanner input)
  {
    System.out.printf("Please enter a password:  %n");
    pswd = input.nextLine();
    return pswd;    
  } //END pswdPrompt()
  
    public static String reversePswd(String pswd)
  {
    revPswd = new StringBuilder(pswd).reverse().toString();
    return revPswd;
  } //END reversePswd()
    
  public static char enDePrompt(Scanner input, String revPswd, String str)
  {
    System.out.printf("Would you like to encrypt or decrpyt \"%s\" (E/D)%n", revPswd);
    str = input.next();
    input.nextLine();
    enDe = str.toUpperCase().charAt(0);
    return enDe;
  } //END enDePrompt()
  
  public static int shiftPrompt(Scanner input)
  {
    System.out.printf("What shift would you like to use? (1 to 94)%n");
    shift = input.nextInt();
    input.nextLine();
    return shift;
  } //END shiftPrompt
  
  public static char enDeSplit(char enDe, String newPswd)
  {
    if(enDe == 'E')
    {
       encrypt.Encrypt(shift);
       erVal = encrypt.erValEn;
       if(erVal == 'Y')
       {
         pswdEn = encrypt.Encrypt(revPswd, pswdEn, en, shift);
         newPswd = pswdEn;
         System.out.printf("You're encrypted password is:  %s%nThe shift in use is %d%n", newPswd, shift);
         enDeVal = 'Y';
       }
       else if(erVal == 'N')
       {
         System.out.printf("Please enter a different shift.%n");
         enDeVal = 'N';
       }
    }
    else if(enDe == 'D')
    {
      decrypt.Decrypt(shift);
      erVal = decrypt.erValDe;
      if(erVal == 'Y')
      {
      pswdDe = decrypt.Decrypt(revPswd, pswdDe, de, shift);
      newPswd = pswdDe;
      System.out.printf("You're decrypted password is:  %s%nThe shift in use is %d.%n", newPswd, shift);
      }
      else if(erVal == 'N')
      {
        System.out.printf("Please enter a different shift.%n");
        enDeVal = 'N';
      }
    }
    return enDeVal;
} //END enDeSplit()

  public static void sysExit()
  {
    System.exit(0);
  } //END sysExit()
} //END class CinCipher